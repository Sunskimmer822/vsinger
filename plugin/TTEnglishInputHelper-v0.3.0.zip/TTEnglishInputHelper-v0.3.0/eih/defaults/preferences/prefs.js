pref("toolkit.defaultChromeURI", "chrome://englishinputhelper/content/index.html");
pref("toolkit.defaultChromeFeatures", "chrome=yes,width=600,height=600");

/*
pref("browser.dom.window.dump.enabled", true);
pref("javascript.options.showInConsole", true);
pref("javascript.options.strict", true);
pref("nglayout.debug.disable_xul_cache", true);
pref("nglayout.debug.disable_xul_fastload", true);
*/
